# © ООО «1С-Софт», 2023.  Все права защищены
# Copyright © 2023, 1C-Soft LLC. All rights  reserved

from time import sleep
from os import path as os_path, SEEK_END
from re import match as re_match
from threading import Thread
from datetime import datetime

from concurrent.futures import ThreadPoolExecutor

from yaml import safe_load as yaml_safe_load, YAMLError
from prometheus_client import start_http_server, Gauge
from psutil import (
    process_iter,
    cpu_percent as ps_cpu_percent,
    virtual_memory as ps_virtual_memory,
    disk_io_counters as ps_disk_io_counters,
    net_io_counters as ps_net_io_counters)

from http import server as http_server
from functools import partial
from json import loads as json_load
from pandas import Series


# --------------------------------------------------------------------------------------------------------------------------
class MainSettings:
    def __init__(self):
        self.__settings = {}

    def open(self, filename):
        with open(filename, 'r') as stream:
            try:
                self.__settings = yaml_safe_load(stream)

                return True
            except YAMLError as exc:
                print(exc)

        return False

    def get(self, key):
        current_value = self.__settings
        settings_path = key.split('/')

        for part in settings_path:
            if part in current_value:
                current_value = current_value[part]
            else:
                return None

        return current_value


# --------------------------------------------------------------------------------------------------------------------------
class RollingMeanMetric():
    def __rolling_mean(self):
        value_size = len(self.__values)
        window = value_size if len(self.__values) < self.__window\
            else self.__window

        return Series(self.__values).rolling(window=window)\
            .mean().iloc[window - 1:].values

    def __init__(self, values=[], timelapses=10, window=2):
        self.__insert_index = 0
        self.__values = values
        self.__timestamp = datetime.now()
        self.__timelapse_count = timelapses
        self.__timelapse = []

        timelapse_count = self.__timelapse_count / 2
        if window and window < timelapse_count:
            timelapse_count = window

        self.__window = timelapse_count
        self.__last_minute_complete = False
        self.__current_summ = 0
        self.__current_count = 0
        self.__accumulation_period = 1

    def add(self, value):
        current_timestamp = datetime.now()
        self.__values.append(value)
        self.__insert_index = self.__insert_index + 1

        if not self.__last_minute_complete:
            self.__current_summ = self.__current_summ + value
            self.__current_count = self.__current_count + 1

        time_diff = (current_timestamp - self.__timestamp).total_seconds()

        if time_diff >= (60 * self.__accumulation_period):
            if len(self.__timelapse) >= self.__window:
                self.__timelapse.pop(0)

            if self.__current_count > 0:
                avg_duration = self.__current_summ / self.__current_count
                self.__timelapse.append(round(avg_duration))

            self.__current_summ = 0
            self.__current_count = 0
            self.__timestamp = current_timestamp

    def get(self):
        result = self.__rolling_mean()
        return 0 if result.size < 1 else round(result[-1])


# --------------------------------------------------------------------------------------------------------------------------
class ApacheRequestMetric:
    def __init__(self, ip, method, infobase, duration, successful):
        self.__ip = ip
        self.__method = method
        self.__infobase = infobase
        self.__duration = duration
        self.__is_successful = successful

    @staticmethod
    def load(ip, method, infobase_name, duration, successful):
        return ApacheRequestMetric(ip,
                                   method,
                                   infobase_name,
                                   duration,
                                   successful)

    ip = property(lambda self: self.__ip)
    method = property(lambda self: self.__method)
    infobase = property(lambda self: self.__infobase)
    duration = property(lambda self: self.__duration)
    successful = property(lambda self: self.__is_successful)


# --------------------------------------------------------------------------------------------------------------------------
class ProcessMetric:
    def __init__(self, pid, name, cpu, memory):
        self.__pid = pid
        self.__name = name
        self.__cpu = cpu
        self.__memory_private = memory
        self.__process = name.split('.')[0]
        self.__metric_key = f'{self.__process}_{pid}'
        self.__description = f'[{pid}] {self.__process}'

    @staticmethod
    def load(proc):
        cpu_percent = proc.cpu_percent(interval=None)
        mem_info = proc.memory_info()

        return ProcessMetric(proc.pid, proc.name(), cpu_percent, mem_info.rss)

    pid = property(lambda self: self.__pid)
    name = property(lambda self: self.__name)
    cpu_percent = property(lambda self: self.__cpu)
    memory = property(lambda self: self.__memory_private)
    process = property(lambda self: self.__process)
    key = property(lambda self: self.__metric_key)
    description = property(lambda self: self.__description)


# --------------------------------------------------------------------------------------------------------------------------
class OSMetric:
    def __init__(self, cpu, memory, free_memory, io_read,
                 io_write, net_recv, net_sent):
        self.__cpu = cpu
        self.__memory = memory
        self.__free_memory = free_memory
        self.__io_read = io_read
        self.__io_write = io_write
        self.__net_recv = net_recv
        self.__net_sent = net_sent

    @staticmethod
    def load(data=''):
        cpu_percent = ps_cpu_percent(interval=None)
        mem_info = ps_virtual_memory()

        io_info = ps_disk_io_counters(perdisk=False, nowrap=True)
        net_info = ps_net_io_counters()
        sleep(5)
        io_info_after = ps_disk_io_counters(perdisk=False, nowrap=True)
        net_info_after = ps_net_io_counters()

        used_memory = mem_info.used
        free_memory = mem_info.free
        io_read = io_info_after.read_bytes - io_info.read_bytes
        io_write = io_info_after.write_bytes - io_info.write_bytes
        bytes_recv = net_info_after.bytes_recv - net_info.bytes_recv
        bytes_sent = net_info_after.bytes_sent - net_info.bytes_sent

        return OSMetric(cpu_percent,
                        used_memory,
                        free_memory,
                        io_read,
                        io_write,
                        bytes_recv,
                        bytes_sent)

    cpu = property(lambda self: self.__cpu)
    memory = property(lambda self: self.__memory)
    free_memory = property(lambda self: self.__free_memory)
    io_read = property(lambda self: self.__io_read)
    io_write = property(lambda self: self.__io_write)
    net_recv = property(lambda self: self.__net_recv)
    net_sent = property(lambda self: self.__net_sent)


# --------------------------------------------------------------------------------------------------------------------------
class DBMSMetric:
    def __init__(self, db, successful, failed, duration):
        self.__failed = failed
        self.__successful = successful
        self.__total = successful + failed
        self.__db = db
        self.__duration = duration

    @staticmethod
    def load(database, metric_values, duration):
        return DBMSMetric(database,
                          metric_values['successful'],
                          metric_values['failed'],
                          duration)

    db = property(lambda self: self.__db)
    failed = property(lambda self: self.__failed)
    successful = property(lambda self: self.__successful)
    total = property(lambda self: self.__total)
    duration = property(lambda self: self.__duration)


# --------------------------------------------------------------------------------------------------------------------------
class AbstractDataRender:
    def __init__(self):
        self._labels = self._metric_labels()

    def metric_labels(self):
        pass

    def render(self, metric):
        pass


# --------------------------------------------------------------------------------------------------------------------------
class WebserverMetricsDataRender(AbstractDataRender):
    def _metric_labels(self):
        return ['type', 'infobase']

    def __init__(self):
        super().__init__()

        self.__total = 0
        self.__successful = 0
        self.__failed = 0

        self.__webserver_requests_count = 'e1c_web_requests'
        self.__duration_gauge_key = 'e1c_web_requests_duration'

        self.__gauge_requests_number = Gauge(self.__webserver_requests_count,
                                             '', self._labels)
        self.__gauge_duration = Gauge(self.__duration_gauge_key,
                                      '', ['infobase'])

    def render(self, metric: ApacheRequestMetric):
        if not metric:
            return

        self.__total += 1

        if metric.successful:
            self.__successful += 1
        else:
            self.__failed += 1

        self.__gauge_requests_number\
            .labels(type='total', infobase=metric.infobase).set(self.__total)
        self.__gauge_requests_number\
            .labels(type='successful', infobase=metric.infobase)\
            .set(self.__successful)
        self.__gauge_requests_number\
            .labels(type='failed', infobase=metric.infobase).set(self.__failed)

        self.__gauge_duration\
            .labels(infobase=metric.infobase)\
            .set(metric.duration)


# --------------------------------------------------------------------------------------------------------------------------
class ProcessMetricsDataRender(AbstractDataRender):
    def _metric_labels(self):
        return ['pid', 'process']

    def _get_metric_key(self, gauge_key, metric):
        return f'{gauge_key}${metric.pid}${metric.process}'

    def _update_stored_metric_data(self, gauge_key, metric, metric_data):
        metric_key = self._get_metric_key(gauge_key, metric)
        self.__metric_data[metric_key] = {"ts": datetime.now(),
                                          "key": gauge_key,
                                          "metric": metric}

    def _init_gauges(self):
        cpu_gauge = Gauge(self.__cpu_gauge_key, 'Процессор, %', self._labels)
        memory_gauge = Gauge(self.__memory_gauge_key, 'Память', self._labels)

        self.__gauges = {self.__cpu_gauge_key: cpu_gauge,
                         self.__memory_gauge_key: memory_gauge}

    def _clear_abandoned_counters(self):
        timestamp = datetime.now()
        keys_to_remove = []

        for current_counter in self.__metric_data.keys():
            current_value = self.__metric_data.get(current_counter)
            if (timestamp - current_value["ts"]).total_seconds() > 15:
                metric = current_value["metric"]
                current_gauge = self.__gauges[current_value["key"]]
                current_gauge.remove(metric.pid, metric.process)

                keys_to_remove.append(current_counter)

        for current_counter in keys_to_remove:
            self.__metric_data.pop(current_counter)

    def __init__(self):
        super().__init__()

        self.__cpu_gauge_key = 'e1c_proccess_cpu'
        self.__memory_gauge_key = 'e1c_proccess_memory'

        self._init_gauges()
        self.__metric_data = {}

    def __set_labels(self, key, metric, type):
        metric_data = f'{type} - {metric.description}'

        self._update_stored_metric_data(key, metric, metric_data)

        return self.__gauges[key].labels(pid=metric.pid,
                                         process=metric.process)

    def clear(self):
        self._clear_abandoned_counters()

    def render(self, metric):
        self.__set_labels(self.__cpu_gauge_key, metric, 'CPU')\
            .set(metric.cpu_percent)
        self.__set_labels(self.__memory_gauge_key, metric, 'RAM')\
            .set(metric.memory)


# --------------------------------------------------------------------------------------------------------------------------
class OSMetricsDataRender(AbstractDataRender):
    def _metric_labels(self):
        return ['title']

    def __init__(self):
        super().__init__()

        self.__cpu_gauge_key = 'e1c_proccess_cpu_total'
        self.__memory_gauge_key = 'e1c_proccess_memory_used'
        self.__memory_free_gauge_key = 'e1c_proccess_memory_free'
        self.__io_write_key = 'e1c_proccess_io_write'
        self.__io_read_key = 'e1c_proccess_io_read'
        self.__net_recv_key = 'e1c_proccess_net_recv'
        self.__net_sent_key = 'e1c_proccess_net_sent'

        self.__cpu_gauge = Gauge(self.__cpu_gauge_key, 'Процессор, %')
        self.__memory_gauge = Gauge(self.__memory_gauge_key,
                                    'Использовано памяти', self._labels)
        self.__free_memory_gauge = Gauge(
            self.__memory_free_gauge_key, 'Свободно памяти', self._labels)
        self.__io_write_gauge = Gauge(
            self.__io_write_key, 'Дисковая подсистема, записано', self._labels)
        self.__io_read_gauge = Gauge(
            self.__io_read_key, 'Дисковая подсистема, прочитано', self._labels)
        self.__net_recv_gauge = Gauge(
            self.__net_recv_key, 'Сетевой интерфейс, принято', self._labels)
        self.__net_sent_gauge = Gauge(
            self.__net_sent_key, 'Сетевой интерфейс, отправлено', self._labels)

    def render_proccesses(self, metric):
        self.__set_labels(self.__cpu_gauge_key, metric).set(metric.cpu_percent)
        self.__set_labels(self.__memory_gauge_key, metric).set(metric.memory)

    def render(self, metric):
        self.__cpu_gauge.set(metric.cpu)
        self.__memory_gauge.labels(title='Использовано')\
            .set(metric.memory)
        self.__free_memory_gauge.labels(title='Свободно')\
            .set(metric.free_memory)
        self.__io_write_gauge.labels(title='Запись')\
            .set(metric.io_write)
        self.__io_read_gauge.labels(title='Чтение')\
            .set(metric.io_read)
        self.__net_recv_gauge.labels(title='Загрузка')\
            .set(metric.net_recv)
        self.__net_sent_gauge.labels(title='Отправка')\
            .set(metric.net_sent)


# --------------------------------------------------------------------------------------------------------------------------
class DBMSMetricsDataRender(AbstractDataRender):
    def _metric_labels(self):
        return ['type', 'infobase']

    def __init__(self):
        super().__init__()

        self.__dbms_calls_key = 'e1c_dbms_calls'
        self.__gauge_dbms_calls = Gauge(self.__dbms_calls_key,
                                        '', self._labels)

        self.__dbms_duration_key = 'e1c_dbms_duration'
        self.__gauge_dbms_duration = Gauge(self.__dbms_duration_key,
                                           '', self._labels)

    def render(self, metric: DBMSMetric):
        if not metric:
            return

        self.__gauge_dbms_calls.labels(type='total', infobase=metric.db)\
            .set(metric.total)
        self.__gauge_dbms_calls.labels(type='successful', infobase=metric.db)\
            .set(metric.successful)
        self.__gauge_dbms_calls.labels(type='failed', infobase=metric.db)\
            .set(metric.failed)
        self.__gauge_dbms_duration.labels(type='duration', infobase=metric.db)\
            .set(metric.duration)


# --------------------------------------------------------------------------------------------------------------------------
class WebserverLogProcessor:
    def __init__(self, settings, sleep_interval=1) -> None:
        self.__sleep_interval = sleep_interval
        self.__line_regex = settings.get('ws-counters/expression')
        self.__path_to_log = settings.get('ws-counters/path')
        self.__infobases_to_monitoring = settings.get(
            'ws-counters/monitoring/infobases')
        self.__renderer = WebserverMetricsDataRender()
        self.__metrics = {}

    def __follow(self, file):
        line = ''

        while True:
            current_line = file.readline()

            if current_line != b'':
                line += current_line.decode("utf-8")

                if line.endswith('\n'):
                    yield line
                    line = ''
            else:
                sleep(self.__sleep_interval)

    def __is_successful_request(self, status_code):
        return status_code >= 100 and status_code < 400

    def __read_metric(self, line):
        infobases_to_monitoring = self.__infobases_to_monitoring
        regex = self.__line_regex

        if not infobases_to_monitoring:
            return None

        match_data = re_match(regex, line)

        if match_data is None:
            return None

        match_groups = match_data.groupdict()

        if 'ip_address' not in match_groups:
            return None

        infobase_name = match_data.group('infobase_name')

        if infobase_name not in infobases_to_monitoring:
            return None

        if infobase_name not in self.__metrics:
            self.__metrics[infobase_name] = RollingMeanMetric()

        ip = match_data.group('ip_address')

        method = (match_data.group('method_name')
                  if match_data.group('method_name')
                  else match_data.group('empty_method'))

        try:
            code = int(match_data.group('status_code'))
        except Exception as _:
            print(_)
            code = 503

        try:
            duration = int(match_data.group('request_duration'))
        except Exception as _:
            print(f'Duration field not matched in log. Reason:\n{_}')
            duration = 0

        is_successful = self.__is_successful_request(code)
        if is_successful:
            self.__metrics[infobase_name].add(duration)

        event_avg_duration = self.__metrics[infobase_name].get()

        return ApacheRequestMetric(ip,
                                   method,
                                   infobase_name,
                                   event_avg_duration,
                                   is_successful)

    def watch(self):
        if not os_path.exists(self.__path_to_log):
            return

        try:
            with open(self.__path_to_log, 'rb') as file:
                file.seek(0, SEEK_END)

                for line in self.__follow(file):
                    current_metric = self.__read_metric(line)
                    self.__renderer.render(current_metric)

        except Exception as ex:
            print(ex)

    def on_rotation_file(self, file):
        self.watch()


# --------------------------------------------------------------------------------------------------------------------------
class ProcessMetricsProcessor:
    def __init__(self, settings) -> None:
        self.__regex_proc = settings.get('process-counters/expression')
        self.__update_sec = settings.get('process-counters/update-sec')
        self.__renderer = ProcessMetricsDataRender()

    def __process_filter(self, proc):
        match = re_match(self.__regex_proc, proc.name())

        return match

    def watch(self):
        while True:
            self.__renderer.clear()

            for proc in process_iter(attrs=['name']):
                if not self.__process_filter(proc):
                    continue

                metric = ProcessMetric.load(proc)
                self.__renderer.render(metric)

            sleep(self.__update_sec)


# --------------------------------------------------------------------------------------------------------------------------
class OSMetricsProcessor:
    def __init__(self, settings) -> None:
        self.__update_sec = settings.get('os-counters/update-sec')
        self.__renderer = OSMetricsDataRender()

    def watch(self):
        while True:
            metric = OSMetric.load()
            self.__renderer.render(metric)

            sleep(self.__update_sec)


# --------------------------------------------------------------------------------------------------------------------------
class DBMSMetricProcessorHandler(http_server.BaseHTTPRequestHandler):
    def __init__(self, renderer, metrics, filter, silent, *args, **kwargs):
        self.__renderer = renderer
        self.__silent = silent
        self.__event_filter = filter
        self.__metrics = metrics

        super().__init__(*args, **kwargs)

    def __process_message(self, message):
        try:
            data_rows = json_load(message.decode('utf-8'))
        except Exception as ex:
            print(ex)
            return

        for current_row in data_rows:
            event_name = current_row['name']
            database_name = None

            if "p:processName" in current_row:
                database_name = current_row["p:processName"]

            if not event_name or not database_name\
               or event_name not in self.__event_filter:
                return

            if database_name not in self.__metrics:
                self.__metrics[database_name] = {"mean": RollingMeanMetric(),
                                                 "failed": 0,
                                                 "successful": 0}

            was_error = False
            metric_data = self.__metrics[database_name]

            if event_name.lower() == "excp":
                if "Exception" in current_row\
                   and current_row["Exception"].lower() == "databaseexception":

                    was_error = True
                    metric_data["failed"] = metric_data["failed"] + 1
            else:
                metric_data["successful"] = metric_data["successful"] + 1

            actual_duration = 0

            try:
                actual_duration = int(current_row['duration'])
            except Exception as e:
                print(e)

            if not was_error:
                self.__metrics[database_name]["mean"].add(actual_duration)

            event_avg_duration = self.__metrics[database_name]["mean"].get()

            current_metric = DBMSMetric.load(database_name,
                                             metric_data,
                                             event_avg_duration)

            self.__renderer.render(current_metric)

    def do_POST(self):
        if self.path == '/':
            req_headers = self.headers.get('Content-Type')
            content_len = self.headers.get('Content-Length')

            if req_headers and content_len\
               and req_headers == 'application/json':
                request_body = self.rfile.read(int(content_len))
                self.__process_message(request_body)

        self.send_response(200)
        self.send_header("Content-type", "text/plain")
        self.end_headers()

    def log_message(self, format, *args):
        if not self.__silent:
            super().log_message(format, *args)


# --------------------------------------------------------------------------------------------------------------------------
class DBMSMetricsProcessor:
    def __init__(self, settings) -> None:
        self.__server = None
        self.__host = settings.get('dbms-counters/host')
        self.__port = settings.get('dbms-counters/port')
        self.__silent = settings.get('dbms-counters/silent')
        self.__metrics = {}

    def __start(self):
        dbms_types = ["DBPOSTGRS",
                      "DBORACLE",
                      "DBMSSQL",
                      "DB2",
                      "SDBL",
                      "EXCP"]
        handler = partial(DBMSMetricProcessorHandler,
                          DBMSMetricsDataRender(),
                          self.__metrics,
                          dbms_types,
                          self.__silent)
        self.__server = http_server.HTTPServer(
            (self.__host, self.__port), handler)

        self.__server.serve_forever()

    def watch(self):
        try:
            self.__start()
        except Exception as ex:
            print(ex)
            return


# --------------------------------------------------------------------------------------------------------------------------
def start_new_watch_thread(settings, processor_name):
    full_section_key = f'{processor_name}-counters'

    if not settings.get(f'{full_section_key}/use'):
        return

    if processor_name == 'os':
        processor = OSMetricsProcessor(settings)
    elif processor_name == 'ws':
        processor = WebserverLogProcessor(settings)

        with ThreadPoolExecutor(1) as thread_executor:
            thread_future = thread_executor.submit(processor.watch)
            thread_future.add_done_callback(processor.on_rotation_file)

    elif processor_name == 'process':
        processor = ProcessMetricsProcessor(settings)
    elif processor_name == 'dbms':
        processor = DBMSMetricsProcessor(settings)
    else:
        return

    metrics_processor_thread = Thread(target=processor.watch)
    metrics_processor_thread.start()


# --------------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':
    settings = MainSettings()

    if not settings.open('settings.yml'):
        exit(1)

    host = settings.get('receiver-parameters/host')
    port = settings.get('receiver-parameters/port')

    try:
        start_http_server(port, host)
    except Exception as ex:
        print(ex)
        exit(1)

    start_new_watch_thread(settings, 'os')
    start_new_watch_thread(settings, 'ws')
    start_new_watch_thread(settings, 'process')
    start_new_watch_thread(settings, 'dbms')
